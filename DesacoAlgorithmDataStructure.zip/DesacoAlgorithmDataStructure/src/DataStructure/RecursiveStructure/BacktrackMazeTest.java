package DataStructure.RecursiveStructure;

public class BacktrackMazeTest {
	public static void main(String[] args) {
		Maze demo = new Maze();
	    demo.init();
	    demo.findPath();
	}
}
