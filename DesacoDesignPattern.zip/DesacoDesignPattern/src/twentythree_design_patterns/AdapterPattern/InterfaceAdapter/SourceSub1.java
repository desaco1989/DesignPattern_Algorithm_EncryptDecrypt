package twentythree_design_patterns.AdapterPattern.InterfaceAdapter;

public class SourceSub1 extends Wrapper2{
	public void method1(){  
        System.out.println("SourceSub1,method1.the sourceable interface's first Sub1!");  
    }
}
