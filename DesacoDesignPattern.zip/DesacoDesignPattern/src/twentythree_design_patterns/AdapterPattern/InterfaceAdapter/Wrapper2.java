package twentythree_design_patterns.AdapterPattern.InterfaceAdapter;

public abstract class Wrapper2 implements Sourceable{
	
	public void method1(){}  
    public void method2(){}
}
