package twentythree_design_patterns.AdapterPattern.InterfaceAdapter;

public interface Sourceable {
	
	public void method1();  
    public void method2();
}
