package twentythree_design_patterns.AdapterPattern.InterfaceAdapter;

public class SourceSub2 extends Wrapper2 {
	public void method2() {
		System.out.println("SourceSub2,method2.the sourceable interface's second Sub2!");
	}
}
