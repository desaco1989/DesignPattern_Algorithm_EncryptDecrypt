package twentythree_design_patterns.AdapterPattern.ObjectAdapter;

public class Source {
	public void method1() {  
        System.out.println("this is original method!");  
    }
}
