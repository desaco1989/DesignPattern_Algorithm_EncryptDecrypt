package twentythree_design_patterns.VisitorPattern;

public interface Visitor {
	public void visit(ISubject sub);
}
