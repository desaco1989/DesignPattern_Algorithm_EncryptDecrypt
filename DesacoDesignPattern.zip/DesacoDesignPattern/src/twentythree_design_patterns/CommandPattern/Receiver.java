package twentythree_design_patterns.CommandPattern;

public class Receiver {
	public void action(){  
        System.out.println("command received!");  
    }
}
