package twentythree_design_patterns.CommandPattern;

public interface ICommand {
	public void exe();
}
