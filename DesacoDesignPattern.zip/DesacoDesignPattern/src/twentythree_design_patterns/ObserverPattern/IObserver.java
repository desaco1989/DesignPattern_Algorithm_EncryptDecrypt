package twentythree_design_patterns.ObserverPattern;

public interface IObserver {
	public void update();
}
