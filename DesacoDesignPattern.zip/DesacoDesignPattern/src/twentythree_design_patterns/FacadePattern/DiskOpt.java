package twentythree_design_patterns.FacadePattern;

public class DiskOpt {
	public void startup() {
		System.out.println("disk startup!");
	}

	public void shutdown() {
		System.out.println("disk shutdown!");
	}
}
