package twentythree_design_patterns.FacadePattern;

public class MemoryOpt {
	public void startup() {
		System.out.println("memory startup!");
	}

	public void shutdown() {
		System.out.println("memory shutdown!");
	}
}
