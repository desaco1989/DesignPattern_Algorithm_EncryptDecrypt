package twentythree_design_patterns.FacadePattern;

public class CPUopt {
	public void startup() {
		System.out.println("cpu startup!");
	}

	public void shutdown() {
		System.out.println("cpu shutdown!");
	}
}
