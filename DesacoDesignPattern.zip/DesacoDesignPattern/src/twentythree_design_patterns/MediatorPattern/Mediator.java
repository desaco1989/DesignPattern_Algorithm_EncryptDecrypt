package twentythree_design_patterns.MediatorPattern;

public interface Mediator {
	
	public void createMediator();  
    public void workAll();
}
