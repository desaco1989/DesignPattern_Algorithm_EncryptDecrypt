package twentythree_design_patterns.FactoryMethod.mutil_factory;

import twentythree_design_patterns.FactoryMethod.Sender;

public class FactoryTest {
	public static void main(String[] args) {  
        SendFactory factory = new SendFactory();  
        Sender sender = factory.produceMail();  
        sender.Send();  
    }
}
