package twentythree_design_patterns.FactoryMethod;

public interface Sender {
	public void Send();
}
