package twentythree_design_patterns.FactoryMethod.static_factory;

import twentythree_design_patterns.FactoryMethod.Sender;

public class FactoryTest {
	public static void main(String[] args) {      
        Sender sender = SendFactory.produceMail();  
        sender.Send();  
    }
}
