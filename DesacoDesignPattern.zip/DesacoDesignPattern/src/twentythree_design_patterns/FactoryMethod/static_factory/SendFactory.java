package twentythree_design_patterns.FactoryMethod.static_factory;

import twentythree_design_patterns.FactoryMethod.MailSender;
import twentythree_design_patterns.FactoryMethod.Sender;
import twentythree_design_patterns.FactoryMethod.SmsSender;

public class SendFactory {
	public static Sender produceMail(){  
        return new MailSender();  
    }  
      
    public static Sender produceSms(){  
        return new SmsSender();  
    }
}
