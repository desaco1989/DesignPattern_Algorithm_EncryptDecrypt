package twentythree_design_patterns.AbstractFactory;

public interface Provider {
	public Sender produce();
}
