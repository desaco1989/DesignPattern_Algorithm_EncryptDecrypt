package twentythree_design_patterns.AbstractFactory;

public interface Sender {
	public void Send();
}
