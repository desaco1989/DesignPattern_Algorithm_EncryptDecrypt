package twentythree_design_patterns.InterpreterPattern;


public interface IExpression {
	public int interpret(Context context); 
}
