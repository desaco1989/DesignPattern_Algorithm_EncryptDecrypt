package twentythree_design_patterns.BuilderPattern;

public interface Sender {
	public void Send();
}
