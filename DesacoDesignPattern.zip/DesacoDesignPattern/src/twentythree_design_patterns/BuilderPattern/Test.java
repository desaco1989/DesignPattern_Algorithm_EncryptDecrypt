package twentythree_design_patterns.BuilderPattern;

public class Test {
	public static void main(String[] args) {  
        Builder builder = new Builder();  
        builder.produceMailSender(10);  
    }
}
