package twentythree_design_patterns.BuilderPattern;

public class SmsSender implements Sender{

	@Override
	public void Send() {
		System.out.println("this is SmsSender!");
	}

}
