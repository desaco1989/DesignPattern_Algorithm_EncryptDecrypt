package twentythree_design_patterns.DecoratorPattern;

public interface Sourceable {
	public void method(); 
}
