package twentythree_design_patterns.ProxyPattern.static_proxy;

public class ProxyTest {
	public static void main(String[] args) {  

        Sourceable source = new Proxy();  
        source.method();  
    } 
}
