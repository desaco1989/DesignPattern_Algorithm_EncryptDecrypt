package twentythree_design_patterns.ProxyPattern.static_proxy;

public interface Sourceable {
	public void method(); 
}
