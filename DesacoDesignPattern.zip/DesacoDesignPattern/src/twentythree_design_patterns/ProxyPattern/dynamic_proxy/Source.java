package twentythree_design_patterns.ProxyPattern.dynamic_proxy;

public class Source implements Sourceable{

	@Override
	public void method() {
		// TODO Auto-generated method stub
		System.out.println("the original method!"); 
	}

}
