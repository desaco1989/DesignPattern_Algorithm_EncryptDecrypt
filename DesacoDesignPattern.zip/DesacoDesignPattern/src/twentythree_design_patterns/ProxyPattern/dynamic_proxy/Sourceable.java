package twentythree_design_patterns.ProxyPattern.dynamic_proxy;

public interface Sourceable {
	public void method(); 
}
