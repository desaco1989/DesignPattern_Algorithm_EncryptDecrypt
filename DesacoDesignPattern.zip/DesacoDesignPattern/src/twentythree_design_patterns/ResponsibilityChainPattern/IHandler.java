package twentythree_design_patterns.ResponsibilityChainPattern;

public interface IHandler {
	public void operator();
}
