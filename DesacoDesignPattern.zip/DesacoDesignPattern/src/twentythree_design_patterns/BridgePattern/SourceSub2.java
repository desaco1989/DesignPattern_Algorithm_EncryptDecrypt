package twentythree_design_patterns.BridgePattern;

public class SourceSub2 implements Sourceable {

	@Override
	public void method() {
		System.out.println("this is the second sub!");
	}

}
