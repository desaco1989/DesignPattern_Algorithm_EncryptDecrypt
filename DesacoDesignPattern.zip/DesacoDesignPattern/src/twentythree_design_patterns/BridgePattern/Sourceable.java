package twentythree_design_patterns.BridgePattern;

public interface Sourceable {
	public void method();
}
