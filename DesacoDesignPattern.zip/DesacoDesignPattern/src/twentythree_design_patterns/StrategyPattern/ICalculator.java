package twentythree_design_patterns.StrategyPattern;

public interface ICalculator {
	public int calculate(String exp);
}
